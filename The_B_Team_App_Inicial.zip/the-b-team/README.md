# The B Team

App PWA de gestão de planeamento de processos/projetos com tema vermelho/preto.

## Objetivo
A Google Sheet no Drive é a base de dados principal. A app lê a folha, apresenta dashboard, prazos, responsáveis, estados, bloqueios e links para Drive.

## A folha começa limpa
O ficheiro Excel fornecido foi usado apenas como referência de layout. Os dados demonstrativos não foram importados.

## Colunas recomendadas na Google Sheet
ID, Projeto, Fase, Tarefa, Equipa, Responsável, Estado, Prioridade, Prazo Parcial, Prazo Final, Dependente de, Percentagem, Link Drive, Observações

## Como ligar ao Google Sheets
1. Criar uma Google Sheet no Drive.
2. Criar uma folha chamada `Planeamento`.
3. Colar os cabeçalhos do ficheiro `docs/google-sheet-template.csv`.
4. Abrir Extensions > Apps Script.
5. Colar o conteúdo de `appsscript/Code.gs`.
6. Fazer Deploy como Web App.
7. Copiar o URL `/exec`.
8. Colar em `src/main.jsx`, variável `CONFIG.APPS_SCRIPT_URL`.

## Executar localmente
```bash
npm install
npm run dev
```

## Gerar versão final
```bash
npm run build
```

## Próximas fases previstas
- Criação automática de eventos no Google Calendar.
- Botão de envio de resumo para Microsoft Teams.
- Autenticação por utilizador.
- Gantt por processo/projeto.
- Vista por colaborador.
- Alertas de bloqueio e dependências.
