// The B Team - Google Sheets API via Apps Script
// 1) Abrir extensions > Apps Script na Google Sheet
// 2) Colar este código
// 3) Deploy > New deployment > Web app
// 4) Access: Anyone with the link ou domínio da empresa
// 5) Copiar o URL /exec para CONFIG.APPS_SCRIPT_URL em src/main.jsx

const SHEET_NAME = 'Planeamento';

function doGet() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName(SHEET_NAME) || ss.getSheets()[0];
  const values = sheet.getDataRange().getValues();
  if (values.length < 2) return json_({ data: [] });

  const headers = values[0].map(h => String(h).trim());
  const data = values.slice(1)
    .filter(row => row.some(cell => cell !== '' && cell !== null))
    .map(row => {
      const obj = {};
      headers.forEach((h, i) => obj[h] = formatCell_(row[i]));
      return obj;
    });

  return json_({ updatedAt: new Date().toISOString(), data });
}

function formatCell_(value) {
  if (value instanceof Date) {
    return Utilities.formatDate(value, Session.getScriptTimeZone(), 'yyyy-MM-dd');
  }
  return value;
}

function json_(payload) {
  return ContentService
    .createTextOutput(JSON.stringify(payload))
    .setMimeType(ContentService.MimeType.JSON);
}
