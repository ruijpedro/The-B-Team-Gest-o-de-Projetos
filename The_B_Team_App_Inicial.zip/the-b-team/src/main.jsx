import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { CalendarClock, Cloud, FileSpreadsheet, FolderOpen, RefreshCcw, ShieldAlert, Users, Send, Search, AlertTriangle, CheckCircle2, Clock3, Link as LinkIcon } from 'lucide-react';
import './styles.css';

const CONFIG = {
  APPS_SCRIPT_URL: '', // Colar aqui o URL /exec do Google Apps Script
  SHEET_URL: '',       // Opcional: link da Google Sheet mestre
  DRIVE_ROOT_URL: '',  // Opcional: link da pasta raiz no Drive
  TEAMS_WEBHOOK_URL: ''// Opcional: webhook do Microsoft Teams
};

const statusMap = {
  'Não iniciado': 'idle',
  'Em curso': 'active',
  'A aguardar': 'waiting',
  'Bloqueado': 'blocked',
  'Concluído': 'done',
  'Atrasado': 'late'
};

function normalizeRow(row, idx) {
  const prazoFinal = row.prazoFinal || row.prazo || row['Prazo Final'] || row['Prazos'] || '';
  const status = row.estado || row.Estado || row.status || 'Não iniciado';
  const pct = Number(row.percentagem || row.Percentagem || row.progresso || 0) || 0;
  return {
    id: row.id || row.ID || row.numero || row['Nº Projeto'] || row['N.º'] || `P-${idx + 1}`,
    projeto: row.projeto || row.Projeto || row['Nome Projeto'] || row.nome || 'Projeto sem nome',
    tarefa: row.tarefa || row.Tarefa || row.fase || row.Fase || '',
    responsavel: row.responsavel || row.Responsável || row['Chefe de Projeto'] || row['Responsável Coordenação'] || '',
    equipa: row.equipa || row.Equipa || '',
    status,
    prioridade: row.prioridade || row.Prioridade || 'Normal',
    prazoParcial: row.prazoParcial || row['Prazo Parcial'] || '',
    prazoFinal,
    dependenteDe: row.dependenteDe || row['Dependente de'] || row.Dependência || '',
    drive: row.drive || row.Drive || row['Link Drive'] || '',
    observacoes: row.observacoes || row.Observações || row['Observações:'] || '',
    percentagem: Math.min(100, Math.max(0, pct))
  };
}

function daysUntil(dateText) {
  if (!dateText) return null;
  const d = new Date(dateText);
  if (Number.isNaN(d.getTime())) return null;
  const today = new Date();
  today.setHours(0,0,0,0);
  d.setHours(0,0,0,0);
  return Math.ceil((d - today) / 86400000);
}

function App() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [query, setQuery] = useState('');
  const [error, setError] = useState('');
  const [lastSync, setLastSync] = useState('Ainda não sincronizado');

  async function sync() {
    setLoading(true);
    setError('');
    try {
      if (!CONFIG.APPS_SCRIPT_URL) {
        setItems([]);
        setLastSync('Configura o URL do Apps Script em src/main.jsx');
        return;
      }
      const res = await fetch(CONFIG.APPS_SCRIPT_URL);
      if (!res.ok) throw new Error(`Erro HTTP ${res.status}`);
      const json = await res.json();
      const rows = Array.isArray(json) ? json : (json.data || []);
      setItems(rows.map(normalizeRow));
      setLastSync(new Date().toLocaleString('pt-PT'));
    } catch (err) {
      setError(err.message || 'Não foi possível sincronizar com a Google Sheet.');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { sync(); }, []);

  const filtered = useMemo(() => {
    const q = query.toLowerCase().trim();
    if (!q) return items;
    return items.filter(i => Object.values(i).join(' ').toLowerCase().includes(q));
  }, [items, query]);

  const stats = useMemo(() => {
    const late = items.filter(i => {
      const d = daysUntil(i.prazoFinal);
      return d !== null && d < 0 && i.status !== 'Concluído';
    }).length;
    return {
      total: items.length,
      active: items.filter(i => ['Em curso', 'A aguardar'].includes(i.status)).length,
      blocked: items.filter(i => i.status === 'Bloqueado').length,
      late,
      done: items.filter(i => i.status === 'Concluído').length
    };
  }, [items]);

  return <main className="app-shell">
    <aside className="sidebar">
      <div className="brand">
        <img src="/assets/icon.svg" alt="The B Team" />
        <div><strong>THE B TEAM</strong><span>Planeamento operacional</span></div>
      </div>
      <nav>
        <a className="active"><ShieldAlert size={18}/> Centro de controlo</a>
        <a><CalendarClock size={18}/> Prazos e entregas</a>
        <a><Users size={18}/> Equipa</a>
        <a><FileSpreadsheet size={18}/> Google Sheets</a>
        <a><FolderOpen size={18}/> Google Drive</a>
        <a><Send size={18}/> Teams</a>
      </nav>
      <div className="integrations">
        <p>Integrações previstas</p>
        <span><Cloud size={15}/> Google Drive</span>
        <span><CalendarClock size={15}/> Google Calendar</span>
        <span><FileSpreadsheet size={15}/> Google Sheets</span>
      </div>
    </aside>

    <section className="content">
      <header className="topbar">
        <div>
          <p className="eyebrow">Mission Control</p>
          <h1>Gestão de processos e projetos</h1>
          <span className="sync-state">Última sincronização: {lastSync}</span>
        </div>
        <button onClick={sync} disabled={loading}><RefreshCcw size={18}/>{loading ? 'A sincronizar...' : 'Sincronizar'}</button>
      </header>

      {error && <div className="alert"><AlertTriangle size={18}/> {error}</div>}

      <section className="cards">
        <Kpi title="Projetos" value={stats.total} icon={<FileSpreadsheet/>}/>
        <Kpi title="Em curso" value={stats.active} icon={<Clock3/>}/>
        <Kpi title="Bloqueados" value={stats.blocked} icon={<ShieldAlert/>}/>
        <Kpi title="Atrasados" value={stats.late} icon={<AlertTriangle/>}/>
        <Kpi title="Concluídos" value={stats.done} icon={<CheckCircle2/>}/>
      </section>

      <section className="panel">
        <div className="panel-head">
          <div><h2>Planeamento mestre</h2><p>A informação vem da Google Sheet no Drive. A folha deve começar limpa.</p></div>
          <label className="search"><Search size={18}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Pesquisar projeto, responsável, estado..."/></label>
        </div>
        <div className="table-wrap">
          <table>
            <thead><tr><th>N.º</th><th>Projeto</th><th>Fase/Tarefa</th><th>Responsável</th><th>Estado</th><th>Prioridade</th><th>Prazo parcial</th><th>Prazo final</th><th>Dependência</th><th>Drive</th></tr></thead>
            <tbody>
              {filtered.length === 0 && <tr><td colSpan="10" className="empty">Sem projetos carregados. Assim que a Google Sheet for alimentada, aparecem aqui automaticamente.</td></tr>}
              {filtered.map((i, idx) => {
                const d = daysUntil(i.prazoFinal);
                const isLate = d !== null && d < 0 && i.status !== 'Concluído';
                return <tr key={`${i.id}-${idx}`} className={isLate ? 'late-row' : ''}>
                  <td>{i.id}</td><td className="strong">{i.projeto}</td><td>{i.tarefa}</td><td>{i.responsavel || i.equipa}</td>
                  <td><span className={`pill ${statusMap[i.status] || 'idle'}`}>{isLate ? 'Atrasado' : i.status}</span></td>
                  <td>{i.prioridade}</td><td>{i.prazoParcial}</td><td>{i.prazoFinal}</td><td>{i.dependenteDe}</td>
                  <td>{i.drive ? <a href={i.drive} target="_blank"><LinkIcon size={15}/> Abrir</a> : '-'}</td>
                </tr>;
              })}
            </tbody>
          </table>
        </div>
      </section>
    </section>
  </main>;
}

function Kpi({title, value, icon}) { return <article className="kpi"><div>{icon}</div><span>{title}</span><strong>{value}</strong></article>; }

createRoot(document.getElementById('root')).render(<App />);
