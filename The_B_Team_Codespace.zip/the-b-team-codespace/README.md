# The B Team — Codespace Ready

App de gestão de planeamento de processos e projetos, preparada para trabalhar como PWA/web e futura APK Android.

## Como arrancar no GitHub Codespaces

1. Cria um repositório no GitHub.
2. Faz upload destes ficheiros para a raiz do repositório.
3. Abre `Code > Codespaces > Create codespace on main`.
4. No terminal do Codespace:

```bash
npm run dev
```

5. Abre a porta 5173.

## Ligação ao Google Sheets

A Google Sheet será a base de dados principal. Deve ter uma folha chamada `Planeamento` com estas colunas:

```text
processo, projeto, tarefa, responsavel, inicio, parcial, final, estado, prioridade, dependencia, drive, progresso, obs
```

O ficheiro `docs/modelo_google_sheets.csv` está limpo e pode ser importado para o Google Sheets.

## Apps Script

1. Na Google Sheet: `Extensões > Apps Script`.
2. Cola o conteúdo de `apps-script/Code.gs`.
3. Publica como Web App.
4. Copia o URL `/exec`.
5. No Codespace, cria o ficheiro `.env` a partir de `.env.example`:

```bash
cp .env.example .env
```

6. Cola o URL em:

```text
VITE_SHEETS_API_URL=...
```

7. Reinicia:

```bash
npm run dev
```

## Build Web

```bash
npm run build
```

## Build Android

O workflow `.github/workflows/build-android.yml` gera o APK debug automaticamente no GitHub Actions.

Também podes fazer manualmente:

```bash
npm run build
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```

## Identidade visual

- Tema: preto/vermelho
- Ícone: letra B limpa, sem A e sem underscore
- Estilo: command center / equipa operacional
