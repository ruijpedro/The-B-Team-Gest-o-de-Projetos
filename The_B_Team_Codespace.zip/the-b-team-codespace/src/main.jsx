import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { AlertTriangle, CalendarDays, CheckCircle2, Clock3, FolderOpen, Gauge, RefreshCcw, Search, Send, ShieldAlert, Users } from 'lucide-react';
import './styles.css';

const SHEETS_URL = import.meta.env.VITE_SHEETS_API_URL || '';

const fallbackTasks = [
  { processo: 'Modelo limpo', projeto: 'Configurar Google Sheet', tarefa: 'Criar colunas base', responsavel: 'Gestor', inicio: '', parcial: '', final: '', estado: 'Por iniciar', prioridade: 'Alta', dependencia: '', drive: '', progresso: 0, obs: 'A folha final começa limpa.' },
  { processo: 'Modelo limpo', projeto: 'Integrações', tarefa: 'Ligar Calendar/Drive/Teams', responsavel: 'Gestor', inicio: '', parcial: '', final: '', estado: 'Por iniciar', prioridade: 'Média', dependencia: '', drive: '', progresso: 0, obs: 'Preparado para configuração.' }
];

function normalizeRows(rows = []) {
  return rows.map((r, i) => ({
    id: r.id || i + 1,
    processo: r.processo || r.Processo || '',
    projeto: r.projeto || r.Projeto || '',
    tarefa: r.tarefa || r.Tarefa || '',
    responsavel: r.responsavel || r.Responsavel || r['Responsável'] || '',
    inicio: r.inicio || r.Inicio || r['Início'] || '',
    parcial: r.parcial || r.Parcial || r['Entrega Parcial'] || '',
    final: r.final || r.Final || r['Entrega Final'] || '',
    estado: r.estado || r.Estado || 'Por iniciar',
    prioridade: r.prioridade || r.Prioridade || 'Média',
    dependencia: r.dependencia || r.Dependencia || r['Dependência'] || '',
    drive: r.drive || r.Drive || r['Link Drive'] || '',
    progresso: Number(r.progresso || r.Progresso || 0),
    obs: r.obs || r.Observacoes || r['Observações'] || ''
  }));
}

function daysUntil(dateText) {
  if (!dateText) return null;
  const d = new Date(dateText);
  if (Number.isNaN(d.getTime())) return null;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  d.setHours(0, 0, 0, 0);
  return Math.ceil((d - today) / 86400000);
}

function App() {
  const [tasks, setTasks] = useState(fallbackTasks);
  const [loading, setLoading] = useState(false);
  const [query, setQuery] = useState('');
  const [status, setStatus] = useState('Modo demonstração — liga o Apps Script no .env');

  async function loadData() {
    if (!SHEETS_URL) return;
    setLoading(true);
    try {
      const res = await fetch(SHEETS_URL);
      const data = await res.json();
      const rows = Array.isArray(data) ? data : data.items || data.rows || [];
      setTasks(normalizeRows(rows));
      setStatus('Sincronizado com Google Sheets');
    } catch (err) {
      setStatus('Erro ao sincronizar. Verifica o URL do Apps Script.');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { loadData(); }, []);

  const filtered = useMemo(() => tasks.filter(t => `${t.processo} ${t.projeto} ${t.tarefa} ${t.responsavel} ${t.estado}`.toLowerCase().includes(query.toLowerCase())), [tasks, query]);
  const total = tasks.length;
  const concluidas = tasks.filter(t => /conclu/i.test(t.estado)).length;
  const bloqueadas = tasks.filter(t => /bloque/i.test(t.estado)).length;
  const atrasadas = tasks.filter(t => { const d = daysUntil(t.final); return d !== null && d < 0 && !/conclu/i.test(t.estado); }).length;
  const criticas = tasks.filter(t => /alta|crítica|critica/i.test(t.prioridade)).length;

  return <div className="app">
    <aside className="sidebar">
      <div className="brandMark">B</div>
      <h1>THE B TEAM</h1>
      <p>Planeamento • Projetos • Missões</p>
      <nav>
        <span><Gauge size={18}/> Dashboard</span>
        <span><CalendarDays size={18}/> Planeamento</span>
        <span><Users size={18}/> Equipa</span>
        <span><FolderOpen size={18}/> Drive</span>
        <span><Send size={18}/> Teams</span>
      </nav>
    </aside>

    <main>
      <header className="topbar">
        <div>
          <p className="eyebrow">Command Center</p>
          <h2>Gestão de planeamento</h2>
        </div>
        <button onClick={loadData} disabled={loading}><RefreshCcw size={18}/> {loading ? 'A sincronizar...' : 'Sincronizar'}</button>
      </header>

      <section className="kpis">
        <Card icon={<Clock3/>} label="Tarefas" value={total}/>
        <Card icon={<ShieldAlert/>} label="Críticas" value={criticas}/>
        <Card icon={<AlertTriangle/>} label="Atrasadas" value={atrasadas}/>
        <Card icon={<CheckCircle2/>} label="Concluídas" value={concluidas}/>
        <Card icon={<AlertTriangle/>} label="Bloqueadas" value={bloqueadas}/>
      </section>

      <section className="panel">
        <div className="panelHead">
          <div>
            <h3>Planeamento da equipa</h3>
            <p>{status}</p>
          </div>
          <label className="search"><Search size={17}/><input placeholder="Pesquisar projeto, responsável, estado..." value={query} onChange={e => setQuery(e.target.value)}/></label>
        </div>

        <div className="tableWrap">
          <table>
            <thead><tr><th>Processo</th><th>Projeto</th><th>Tarefa</th><th>Responsável</th><th>Parcial</th><th>Final</th><th>Estado</th><th>Prioridade</th><th>Prog.</th><th>Drive</th></tr></thead>
            <tbody>{filtered.map(t => <tr key={t.id}>
              <td>{t.processo}</td><td>{t.projeto}</td><td>{t.tarefa}</td><td>{t.responsavel}</td><td>{t.parcial}</td><td>{t.final}</td>
              <td><span className={`pill ${slug(t.estado)}`}>{t.estado}</span></td>
              <td><span className={`priority ${slug(t.prioridade)}`}>{t.prioridade}</span></td>
              <td><div className="bar"><i style={{width: `${Math.min(100, Math.max(0, t.progresso))}%`}}/></div></td>
              <td>{t.drive ? <a href={t.drive} target="_blank">Abrir</a> : '—'}</td>
            </tr>)}</tbody>
          </table>
        </div>
      </section>
    </main>
  </div>;
}

function Card({ icon, label, value }) { return <article className="card"><div>{icon}</div><span>{label}</span><strong>{value}</strong></article>; }
function slug(v='') { return v.toString().normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/\s+/g,'-'); }

createRoot(document.getElementById('root')).render(<App />);
