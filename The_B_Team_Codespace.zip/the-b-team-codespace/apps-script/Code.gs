const SHEET_NAME = 'Planeamento';

function doGet() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sh = ss.getSheetByName(SHEET_NAME);
  if (!sh) return json_({ error: 'Folha Planeamento não encontrada' });

  const values = sh.getDataRange().getValues();
  if (values.length < 2) return json_({ items: [] });

  const headers = values[0].map(h => String(h).trim());
  const items = values.slice(1)
    .filter(row => row.some(cell => cell !== ''))
    .map((row, idx) => {
      const obj = { id: idx + 1 };
      headers.forEach((h, i) => obj[h] = format_(row[i]));
      return obj;
    });

  return json_({ items });
}

function json_(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

function format_(value) {
  if (Object.prototype.toString.call(value) === '[object Date]') {
    return Utilities.formatDate(value, Session.getScriptTimeZone(), 'yyyy-MM-dd');
  }
  return value;
}
